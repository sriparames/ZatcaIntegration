# ZatcaIntegration

Zatca fatoora integration second phase in KSA
This is simple c# windows form application that will help you to create simplified invoice,standard invoice,debit and credit notes as xml file with zatca instructions in ubl format then sign the xml file to be ready for integertation with Zatca systems. 

Write to me if you need support

Contact information

email:amrsobhy57@gmail.com

linkedin:https://www.linkedin.com/in/amr-sobhy-9a2841b4

whatsapp:+201090838734

